function mostrar()
{
//tomo la edad  
var mesDelAño = document.getElementById('mes').value;




}//FIN DE LA FUNCIÓN