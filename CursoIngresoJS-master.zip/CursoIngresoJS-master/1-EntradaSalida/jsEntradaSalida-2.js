/*Debemos lograr tomar un nombre con 'prompt' 
y luego mostrarlo por 'alert' al presionar el botón  'mostrar'*/
function mostrar()
{
    var nombre; //Declaramos la variable 
    nombre = prompt("Ingrese un dato", "El dato"); //Aclaramos que vamos a guardar el valor dentro de la variable  
    alert(nombre); // Utilizamos la función "ALERT" para mostrar por pantalla el valor guardado
	
}

