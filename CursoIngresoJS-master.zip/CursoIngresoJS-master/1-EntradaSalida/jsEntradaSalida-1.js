//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{
	alert("Esto funciona de maravilla"); //El archivo sobre el que queremos mostrar los cambios tiene que ser el mismo que tengamos abierto desde el compilador
/*Bienvenidos. 
Al presionar el botón, se debe mostrar un mensaje como el siguiente "Esto funciona de maravilla".*/

}

